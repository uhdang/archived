# Tech Application ROADMAP

## Web Development
- Overall Website

## Data Collection
- Data Input + Display via Platform

## Machine Learning Application
- 

## Data Analysis
- Grafana
- Prometheus

## Worker

## Crawler for .. 
- historical event in wikipedia