# recipe_server


# Docker Command
## Create Image
$ docker build -t [IMAGENAME] .

## Run a conatiner
$ docker run -p 7777:7777 --name [CONTAINERNAME] [IMAGENAME]
