# Database Related Commands

## Create Database
CREATE DATABASE cooking;

## Create Table
CREATE TABLE user
(
    username    VARCHAR(15),
    email       VARCHAR(15),
    password    VARCHAR(15)
);