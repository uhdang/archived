package com.jeong.cooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(CookingApplication.class, args);
	}
}
