import {Request, Response} from 'express';

export const deleteUser = (req:Request, res:Response) => {
    // DELETE USER
};
