# Database Setup

1. Pull mysql docker image. tag:8.0.11 
$ docker pull mysql:8.0.11
2. Run a container - shell script availalbe - mysql\_docker\_run.sh 
*mysql docker image v8 has auth problem. So, we are using 5.7.22 next latest
