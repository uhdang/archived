# IDEAS

- Create a section for _recommended choice of song_ or _a playlist_ with a music player where a user looking at that recipe could listen to it right away while following the recipe.
