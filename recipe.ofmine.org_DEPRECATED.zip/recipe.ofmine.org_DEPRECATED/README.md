# Instruction

## 1. Use virtualenv + Install Requirement Packages in a virtual environment

- Initialize
$ virutalenv [DIRNAME]

- Start virtualenv
$ source [DIRNAME]/bin/activate

- Install packages from requirement file
$ pip install -r [REQUIREMENT FILE]


